package com.niit.furnitureshop.controller;





import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.furnitureshop.dao.SupplierDAO;



@Controller
public class SupplierController{
//	@Autowired
//	SupplierDAO supplierDAO;
//	
//	@Autowired
//	Supplier supplier;
//	
//	// @RequestMapping("/supplier")
//	//public String getSupplier()
//	//{
//	//	return "supplier";
//	//	}
//	@RequestMapping("/supplier")
//	public ModelAndView getRegister(Model m)
//	{
//		m.addAttribute("supplier",new Supplier());
//		ModelAndView model = new ModelAndView("Supplier");
//		
//		return model;
//		
//	}
//	@RequestMapping(value="supplier/add", method=RequestMethod.POST)
//	public String addUser(Model model,@Valid @ModelAttribute("supplier") Supplier supplier)
//	{
//		supplierDAO.addSupplier(supplier);
//		return "redirect:/supplier";
//	}
}